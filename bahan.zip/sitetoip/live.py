# -*- coding: utf-8 -*-
from __future__ import unicode_literals
#!/usr/bin/python

# Coded By Ghazascanner 
# Turkey

import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,colorama,requests
from multiprocessing.dummy import Pool                             
from time import time as timer    
import time
from time import time as timer
from platform import system  
import urllib
import urllib3
from urllib import urlopen
from random import sample as rand
from Queue import Queue                           
from platform import system
from urlparse import urlparse
from optparse import OptionParser    
from colorama import Fore                                
from colorama import Style                                
from pprint import pprint                                
from colorama import init                                                
import traceback
from bs4 import BeautifulSoup
import subprocess
import warnings
from datetime import datetime
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
reload(sys)  
sys.setdefaultencoding('utf8')                                              
init(autoreset=True) 
                                        
                                                            
####### Colors     ######    
    
fr  =   Fore.RED                                            
fc  =   Fore.CYAN                                            
fw  =   Fore.WHITE                                            
fg  =   Fore.GREEN                                            
sd  =   Style.DIM                                            
sn  =   Style.NORMAL                                        
sb  =   Style.BRIGHT                                        

####################### 
def logo():
    clear = "\x1b[0m"
    colors = [32]

    x = """

       _                                                        
      | |                                                       
  __ _| |__   __ _ ______ _ ___  ___ __ _ _ __  _ __   ___ _ __ 
 / _` | '_ \ / _` |_  / _` / __|/ __/ _` | '_ \| '_ \ / _ \ '__|
| (_| | | | | (_| |/ / (_| \__ \ (_| (_| | | | | | | |  __/ |   
 \__, |_| |_|\__,_/___\__,_|___/\___\__,_|_| |_|_| |_|\___|_|   
  __/ |\033[0;37;41m[WVS v 0.1 Special osCommerce,zenbot,vBulletin]\033[0;40m
 |___/                                                          

    \033[0;37;41m[ Coded by M4L1KL8590X ]
    \033[0;37;41m[ICQ:https://icq.im/greatzcode]
    \033[0;37;41m[Not responsible for any illegal usage of this tool.]
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.05)
logo()

start_raw = raw_input("\n\033[91mGhazascanner\033[97m:~# \033[97m")
crownes = raw_input("\033[91mthread \033[97m\033[97m:~# \033[97m")
try:
    with open(start_raw, 'r') as f:
        ooo = f.read().splitlines()
        ooo = list((ooo))
except IOError:
    print("open your eyes!")

class Master:
           

 
    def osrce(self,url):

        site = url
        try:
            dsdk = requests.get(url,timeout=5)
            if dsdk.status_code == 200:
                print "[ Live ]: "+url
                open('Live.txt', 'a').write(url+'\n')
            else:
                print "[ Live ]: "+url
                
                open('Live.txt', 'a').write(url+'\n')
        except:
            print "[ DIE ]: "+url





BotMaster = Master()


def MyLove(url):
    
    try:
        if 'http' not in url:
            site = 'http://'+url
            url = 'http://'+url
            BotMaster.osrce(site)
        else:
            site = url
            BotMaster.osrce(site)
    except:
        pass




def Main():
    try:
        
        start = timer()
        ThreadPool = Pool(int(crownes))
        Threads = ThreadPool.map(MyLove, ooo)
    except:
        pass


if __name__ == '__main__':
    Main()
