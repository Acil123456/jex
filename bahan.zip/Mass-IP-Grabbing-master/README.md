# Mass-IP-Grabbing
Mass IP Grabbbing From Bing | Mr.MaGnoM
{ Tools only run on windows operating system }

# Support And Follow
http://www.exploit1337.com/ 
